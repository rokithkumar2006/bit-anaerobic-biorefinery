"""FastAPI adapter for the supplied PyADM1ODE repository.

The campus food/garden mappings are explicitly provisional substrate proxies.
This adapter returns actual PyADM1ODE outputs; it does not claim local-waste
calibration or experimental validation.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "vendor" / "PyADM1ODE-master"
if not (REPO / "pyadm1").is_dir():
    raise RuntimeError(f"PyADM1ODE source directory not found: {REPO}")
sys.path.insert(0, str(REPO))

app = FastAPI(title="BIT Anaerobic Biorefinery — PyADM1ODE Adapter", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict to the deployed frontend domain before public deployment.
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

class SimulationRequest(BaseModel):
    feed_rate_kg_day: float = Field(600, gt=0, le=100000)
    food_share_pct: float = Field(55, ge=0, le=100)
    garden_share_pct: float = Field(15, ge=0, le=100)
    temperature_c: float = Field(37, ge=20, le=60)
    hrt_days: float = Field(25, ge=1, le=200)
    duration_days: int = Field(30, ge=5, le=365)
    timestep_hours: float = Field(6, ge=1, le=24)

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "engine": "PyADM1ODE / ADM1da",
        "engine_source_present": (REPO / "pyadm1").is_dir(),
        "note": "Health check does not imply that a simulation has been run or validated for BIT feedstock.",
    }

@app.post("/api/simulate")
def simulate(req: SimulationRequest):
    if req.food_share_pct + req.garden_share_pct > 100:
        raise HTTPException(status_code=422, detail="Food and garden shares must sum to 100% or less.")
    started = time.time()
    try:
        from pyadm1 import BiogasPlant, Feedstock
        from pyadm1.configurator.plant_configurator import PlantConfigurator

        # IMPORTANT: provisional proxy mapping, not a measured characterization
        # of BIT waste. ADM1's Feedstock API expects volumetric flow in m³/day.
        # A provisional 1000 kg/m³ conversion is explicitly disclosed below.
        density_assumption_kg_m3 = 1000.0
        total_q_m3_day = req.feed_rate_kg_day / density_assumption_kg_m3
        food_pct = req.food_share_pct
        garden_pct = req.garden_share_pct
        remainder_pct = max(0.0, 100.0 - food_pct - garden_pct)
        # Repository substrate proxies: onion_waste (food), grass_silage (green
        # waste), maize_silage_milk_ripeness (remaining organic fraction).
        ids = ["onion_waste", "grass_silage", "maize_silage_milk_ripeness"]
        shares = [food_pct, garden_pct, remainder_pct]
        q_substrates = [total_q_m3_day * x / 100.0 for x in shares]
        feedstock = Feedstock(ids, feeding_freq=24, total_simtime=req.duration_days + 1)
        plant = BiogasPlant("BIT campus organic waste — provisional proxy scenario")
        cfg = PlantConfigurator(plant, feedstock)
        # Volume is derived from estimated volumetric feed and the requested HRT.
        liquid_volume = max(1.0, total_q_m3_day * req.hrt_days)
        cfg.add_digester(
            digester_id="main_digester",
            V_liq=liquid_volume,
            V_gas=max(0.1, liquid_volume * 0.15),
            T_ad=req.temperature_c + 273.15,
            Q_substrates=q_substrates,
            k_L_a=200.0,
        )
        plant.initialize()
        results = plant.simulate(
            duration=float(req.duration_days),
            dt=req.timestep_hours / 24.0,
            save_interval=1.0,
        )
        if not results:
            raise RuntimeError("PyADM1ODE returned no saved simulation results.")
        series = []
        for item in results:
            dig = item.get("components", {}).get("main_digester", {})
            gas = float(dig.get("Q_gas", 0.0) or 0.0)
            methane = float(dig.get("Q_ch4", 0.0) or 0.0)
            series.append({
                "day": float(item.get("time", 0.0)),
                "biogas_m3_day": gas,
                "methane_m3_day": methane,
                "methane_fraction_pct": (100.0 * methane / gas) if gas > 0 else 0.0,
                "pH_model_output": dig.get("pH"),
                "vfa_g_l": dig.get("VFA"),
                "tac_g_l": dig.get("TAC"),
                "hrt_days_model_output": dig.get("HRT"),
                "liquid_volume_m3": dig.get("V_liq", liquid_volume),
            })
        # Report the final saved point and the mean of the final 20% of saved
        # samples as separate fields; do not imply steady state automatically.
        tail_count = max(1, len(series) // 5)
        tail = series[-tail_count:]
        avg = lambda key: sum(float(p.get(key) or 0.0) for p in tail) / len(tail)
        final = series[-1]
        return {
            "engine": "PyADM1ODE / ADM1da",
            "model_status": "mechanistic simulation executed; not calibrated or experimentally validated for BIT waste",
            "runtime_seconds": round(time.time() - started, 3),
            "inputs": req.model_dump() if hasattr(req, "model_dump") else req.dict(),
            "assumptions": [
                "Feed mass converted to volume using provisional density 1000 kg/m³; replace with measured blended density.",
                "onion_waste is used as a food-waste proxy; grass_silage as a garden-waste proxy; maize silage as the remainder proxy.",
                "The supplied repository substrate definitions are not measured BIT campus feedstock characterization.",
                "pH is a model output in this ADM1 workflow, not a directly forced input slider.",
                "The mean of the final saved samples is a tail-period average, not proof of steady state.",
            ],
            "substrate_proxy_mapping": dict(zip(ids, shares)),
            "flow_conversion": {"assumed_density_kg_m3": density_assumption_kg_m3, "total_feed_m3_day": total_q_m3_day},
            "final": final,
            "tail_period_mean": {
                "biogas_m3_day": avg("biogas_m3_day"),
                "methane_m3_day": avg("methane_m3_day"),
                "methane_fraction_pct": avg("methane_fraction_pct"),
            },
            "time_series": series,
        }
    except HTTPException:
        raise
    except Exception as exc:
        # Keep traceback in server logs; return a concise error to the client.
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"PyADM1ODE simulation failed: {type(exc).__name__}: {exc}") from exc
