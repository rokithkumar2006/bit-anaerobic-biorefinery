# BIT PyADM1ODE backend deployment

## GitHub
1. Create a separate GitHub repository, e.g. `bit-pyadm1ode-backend`.
2. Extract this ZIP on your computer.
3. Upload the CONTENTS of the extracted `BIT_Backend_GitHub_Ready` folder to the repository root. Do not upload only the ZIP file.
4. Commit to the `main` branch.

## Render
1. Open https://dashboard.render.com/ and create a New Web Service.
2. Connect the `bit-pyadm1ode-backend` repository.
3. Render should detect `render.yaml`. If it asks manually: build command `pip install -r requirements.txt`; start command `uvicorn main:app --host 0.0.0.0 --port $PORT`.
4. After deployment, open `https://YOUR-SERVICE.onrender.com/api/health`. Expect JSON with `"status":"ok"`.
5. API documentation: `https://YOUR-SERVICE.onrender.com/docs`.
6. In the website's PyADM1ODE panel, replace the local URL with `https://YOUR-SERVICE.onrender.com`.

## Important
- This backend runs a mechanistic PyADM1ODE model with provisional substrate proxies, not measured BIT waste characterization. It is not calibrated or experimentally validated for campus feedstock.
- If build fails, inspect Render build logs; the free instance may sleep when idle and first requests can take longer.
- Before public use, restrict CORS in `main.py` to your deployed Vercel domain instead of `*`.
- Keep the upstream PyADM1ODE license and attribution in `vendor/PyADM1ODE-master/LICENSE`.
